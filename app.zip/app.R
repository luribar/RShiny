############################################################################################################
### Evaluación Unidad 2 "IntroducciÃ³n al AnÃ¡lisis espacial y Webmapping con Google Earth Engine y R Shiny"
### Lucas Rivero Iribarne - mail: lri.4495@gmail.com - lucas.rivero@ug.uchile.cl
############################################################################################################

############################################################################################################
### El siguiente script corresponde a una "ShinyApp" que permite:
###
### 1. Activar y desactivar capa cargada (puntosVerdesyLimpios_MMA.gpkg;)
### 2. Cambiar la simbología de forma dinámica considerando las columnas de la tabla de atributos
### 3. Emplear un mapa base de algún proveedor específico
### 4. Disponer de etiquetas para la información desplegada
###
############################################################################################################


# Cargar Librerias ----

library(shiny)
library(tidyverse)
library(sf)
library(rgdal)
library(leaflet)

# Directorio de trabajo ----

#setwd("D:/Curso_RShiny_&_GEE/Unidad_2/Eval_unidad_2")

########### UI #######################
ui <- bootstrapPage(
  tags$style(type = "text/css", "html, body {width:100%;height:100%}"),
  leafletOutput('map', width = "100%", height = "100%"),
  
# Panel Lateral
  absolutePanel(id="controls",
                style="z-index:500;", top = 90, left = "auto", right = 20,bottom = "auto",
                width = 400, height ="auto",class = "panel panel-default",
                
                # Barra selección de variables 
                selectInput(inputId = "variable",label = 'Material reciclable:',
                            choices = c("glass","paper","plastic","phone"), selected = "glass")
  )
)
############SERVER###################
server <- function(input, output, session) {
  #cargar datos, transformarlo en puntos para cargar en leaflet y reproyectar
  pts <- read_sf('data/vect/puntosVerdesyLimpios_MMA.gpkg') %>% st_cast("POINT") %>% st_transform(4326)
  
  # Render mapa
  output$map <- renderLeaflet({
    leaflet() %>% addProviderTiles(providers$OpenStreetMap) %>% 
      setView(lat =-33.0236 ,lng =-71.5658, zoom = 9) # ajustar extensión inicial del mapa
  })
  
  #mapa temático en proxy
  observeEvent(input$variable, {
    tabla <- pts %>% select(input$variable) # seleccionar columna de interés
    
    # Paleta de colores para puntos en leaflet
    pal <- colorFactor(
      palette = c('red', 'green'),
      domain = tabla[[input$variable]])
    
    # Paleta de colores para leyenda
    pal_colors = c("red", "green")
    pal_labels <- c("No", "Si")
    
    # mapa reactivo
    proxyMap <- leafletProxy('map') %>% clearControls() %>% clearShapes()
    
    # Condicional por variable para mapa reactivo
    if(input$variable == "glass"){
      proxyMap %>% addCircleMarkers(data = tabla, group = 'Sitios reciclaje', fillColor = ~pal(glass), 
                               fillOpacity = 0.8,stroke = T,weight = 0.25,
                               popup = ~glass %>% as.character()) %>%
        addLegend("bottomleft", colors = pal_colors, labels = pal_labels, 
                  title = "Reciclaje vidrio",opacity = 0.8,group = 'Leyenda') %>% 
        addLayersControl(overlayGroups = c('Sitios reciclaje'),position ="bottomleft")
    }
    
    if(input$variable == "paper"){
      proxyMap %>% addCircleMarkers(data = tabla, group = 'Sitios reciclaje', fillColor = ~pal(paper), 
                                    fillOpacity = 0.8,stroke = T,weight = 0.25,
                                    popup = ~paper %>% as.character()) %>%
        addLegend("bottomleft", colors = pal_colors, labels = pal_labels, 
                  title = "Reciclaje papel",opacity = 0.8,group = 'Leyenda') %>% 
        addLayersControl(overlayGroups = c('Sitios reciclaje'),position ="bottomleft")
    }
    
    if(input$variable == "plastic"){
      proxyMap %>% addCircleMarkers(data = tabla, group = 'Sitios reciclaje', fillColor = ~pal(plastic), 
                                    fillOpacity = 0.8,stroke = T,weight = 0.25,
                                    popup = ~plastic %>% as.character()) %>%
        addLegend("bottomleft", colors = pal_colors, labels = pal_labels, 
                  title = "Reciclaje plástico",opacity = 0.8,group = 'Leyenda') %>% 
        addLayersControl(overlayGroups = c('Sitios reciclaje'),position ="bottomleft")
    }
    
    if(input$variable == "phone"){
      proxyMap %>% addCircleMarkers(data = tabla, group = 'Sitios reciclaje', fillColor = ~pal(phone), 
                                    fillOpacity = 0.8,stroke = T,weight = 0.25,
                                    popup = ~phone %>% as.character()) %>%
        addLegend("bottomleft", colors = pal_colors, labels = pal_labels, 
                  title = "reciclaje teléfonos",opacity = 0.8,group = 'Leyenda') %>% 
        addLayersControl(overlayGroups = c('Sitios reciclaje'),position ="bottomleft")
    }
    
  })
  
  
}
##########Compile####################
shinyApp(ui,server)
